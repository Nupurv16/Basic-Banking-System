# Banking_App
This is an android project made under the internship program by The Sparks Foundation.
This is an android application which can perform basic banking functions like transactions, viewing history, viewing bank holders details, etc.
